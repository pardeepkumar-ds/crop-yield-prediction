# Crop Yield Prediction Using Machine Learning

**Student:** Pardeep Kumar  
**Project:** Forecasting crop yield (tonnes/hectare) from climate, pesticide use, crop, and country.

## What is in this submission

```
Pardeep_Kumar_CropYield_Submission/
├── README.md
├── requirements.txt
├── Pardeep_kumar_cropyieldproduction.ipynb   # full pipeline, already executed
└── data/
    ├── rainfall.csv          # World Bank average annual rainfall
    ├── pesticides.csv        # FAO pesticide use (tonnes)
    ├── temp.csv              # average temperature by country and year
    ├── yield.csv             # FAO crop yield (hg/ha)
    └── yield_df.csv          # pre-merged modelling table (101 countries, 10 crops, 1990–2013)
```

The notebook is the working code. It loads the raw files, checks missing values and country-name mismatches, cleans `yield_df.csv`, engineers features, trains Linear, Ridge, Lasso, Polynomial, and Random Forest models, and compares them. Outputs and figures from a full run are saved in the notebook.

## How to run

From this folder (the folder that contains `data/`):

```bash
pip install -r requirements.txt
jupyter notebook Pardeep_kumar_cropyieldproduction.ipynb
```

Then run all cells. The notebook looks for each CSV in the current folder and in `data/`, so it runs after a normal unzip as long as Jupyter is started from this folder.

## Result of the saved run

25,932 country–crop–year records after removing 2,310 duplicate rows. 116 features after encoding.

| Model | R² | RMSE (t/ha) | MAE (t/ha) |
|---|---:|---:|---:|
| Random Forest | 0.9780 | 1.263 | 0.570 |
| Linear Regression | 0.7488 | 4.267 | 2.991 |
| Ridge Regression | 0.7486 | 4.268 | 2.987 |
| Polynomial Regression | 0.7483 | 4.271 | 3.004 |
| Lasso Regression | 0.7273 | 4.446 | 2.972 |

Random Forest is the model to use when accuracy matters. The linear models are kept because their coefficients are easier to explain. Crop identity (especially potatoes) is the strongest single feature; country and climate matter most once the crop is fixed.

## Data note

Raw climate files are messy on purpose in this check: 780 rainfall readings and 2,547 temperature readings are missing or non-numeric, and country names do not match across agencies. Modelling uses `yield_df.csv`, the reconciled table, then applies this project's own cleaning and feature engineering on top.
